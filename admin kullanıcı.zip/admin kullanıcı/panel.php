<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
   
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurumsal Admin Paneli</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333;
        }

        .navbar {
            background-color: rgb(36, 64, 99);
            color: white;
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .navbar-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 40px;
        }

        .navbar-header img {
            width: 80px;
            height: auto;
            margin-bottom: 15px;
            border-radius: 50%;
        }

        .navbar-header h1 {
            font-size: 20px;
            margin: 0;
            font-weight: bold;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 12px 15px;
            font-weight: 500;
            margin: 5px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            display: flex;
            align-items: center;
        }

        .navbar a:hover {
            background-color:rgb(36, 64, 99);
            transform: translateX(5px);
        }

        .navbar a i {
            margin-right: 10px;
        }

        .content {
            margin-left: 270px;
            padding: 40px;
            flex: 1;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .dashboard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
            margin-top: 20px;
        }

        .stat-box {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            width: 23%;
            min-width: 200px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-box h3 {
            font-size: 18px;
            color: #343a40;
            margin-bottom: 15px;
        }

        .stat-box p {
            font-size: 16px;
            color: #6c757d;
        }

        .table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }

        .table th, .table td {
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            color: #495057;
        }

        .table th {
            background-color: rgb(36, 64, 99);
            color: white;
        }

        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 15px 0;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="navbar-header">
            <img src="https://cdn.tassandigi.com/2024/04/renk-degistiren-dogal-taslar.jpeg" alt="">
            <h1>Doğal Taş</h1>
        </div>
        <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
        <a href="setting.php"><i>⚙️</i> Ayarlar</a>
        <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
        <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
    </div>

    <div class="content">
        <h1>Kurumsal Admin Paneli</h1>
        <p>Panel üzerinden işlemlerinizi hızlıca gerçekleştirebilirsiniz.</p>
       
        <div class="dashboard">
            <div class="stat-box">
                <h3>Ziyaretçi Sayısı</h3>
                <p>1500 Ziyaretçi</p>
            </div>
            <div class="stat-box">
                <h3>Toplam Satış</h3>
                <p>5000 TL</p>
            </div>
            <div class="stat-box">
                <h3>Stok Durumu</h3>
                <p>120 Ürün</p>
            </div>
        </div>

        <div class="dashboard">
            <div class="stat-box">
                <h3>Aktif Kampanyalar</h3>
                <p>3 Kampanya</p>
            </div>
            <div class="stat-box">
                <h3>Reklamlar</h3>
                <p>5 Reklam</p>
            </div>
            <div class="stat-box">
                <h3>Trafik Kaynakları</h3>
                <p>Google, Sosyal Medya</p>
            </div>
            <div class="stat-box">
                <h3>Sayfa Görüntüleme</h3>
                <p>25,000 Görüntüleme</p>
            </div>
            <div class="stat-box">
                <h3>Toplam Satış Sayısı</h3>
                <p>100+ Ürün</p>
            </div>
            <div class="stat-box">
                <h3>Günlük Satış Sayısı</h3>
                <p>5 Ürün</p>
            </div>
        </div>

        <div class="dashboard">
            <div class="stat-box">
                <h3>En Popüler Ürün</h3>
                <p>Mermer Taşı</p>
            </div>
            <div class="stat-box">
                <h3>En Çok Alınan Ürün</h3>
                <p>Mermer Taşı</p>
            </div>
            <div class="stat-box">
                <h3>Yeni Kayıtlı Kullanıcılar</h3>
                <p>15 Kullanıcı</p>
            </div>
        </div>
        <div class="dashboard">
            <div class="stat-box">
                <h3>Toplam Gelir</h3>
                <p>12,000 TL</p>
            </div>
            <div class="stat-box">
                <h3>Gelir Trafiği</h3>
                <p>%15 Artış</p>
            </div>
            <div class="stat-box">
                <h3>Ödeme Yöntemleri</h3>
                <p>Kredi Kartı, Havale</p>
            </div>
        </div>
    </div>

        <div class="table-container">
            <h2>Son Siparişler</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Sipariş No</th>
                        <th>Müşteri</th>
                        <th>Tarih</th>
                        <th>Tutar</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#00123</td>
                        <td>Ahmet Yılmaz</td>
                        <td>2024-12-19</td>
                        <td>350 TL</td>
                    </tr>
                    <tr>
                        <td>#00124</td>
                        <td>Ayşe Demir</td>
                        <td>2024-12-18</td>
                        <td>220 TL</td>
                    </tr>
                    <tr>
                        <td>#00125</td>
                        <td>Mehmet Kaya</td>
                        <td>2024-12-17</td>
                        <td>500 TL</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="table-container">
            <h2>Kargo Takip</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Sipariş No</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#00123</td>
                        <td>Yolda</td>
                        <td>2024-12-19</td>
                    </tr>
                    <tr>
                        <td>#00124</td>
                        <td>Teslim Edildi</td>
                        <td>2024-12-18</td>
                    </tr>
                    <tr>
                        <td>#00125</td>
                        <td>Hazırlanıyor</td>
                        <td>2024-12-17</td>
                    </tr>
                </tbody>
            </table>
        </div>

       

    <div class="footer">
        © 2024 Doğal Taş Satışı
    </div>
</body>
</html>