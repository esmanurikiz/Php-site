<?php

$servername = "localhost"; 
$username = "root";       
$password = "";        
$dbname = "natural_stones"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>
