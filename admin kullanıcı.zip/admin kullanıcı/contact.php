<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doğal Taşlar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #3d3d3d;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        nav {
            width: 100%;
            background-color: #B39DDB;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            margin-left: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: space-around;
            width: 50%;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }

        nav ul li a:hover {
            color: #8A2BE2;
        }

        .navbar, .cart {
            font-size: 18px;
            color: white;
            margin-right: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            text-decoration: none; 
        }

        .navbar a, .cart a {
            display: flex;
            align-items: center;
            color: white; 
            text-decoration: none;
        }

        .navbar:hover a, .cart:hover a {
            color: #8A2BE2; 
        }

        .navbar i, .cart i {
            margin-right: 8px;
            font-size: 22px;
        }

        .contact-container {
            background-color: #f4f4f4;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 750px;
            width: 100%;
            margin: 40px auto;
        }

        h1 {
            text-align: center;
            color: #6a0dad;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }

        .form-group label {
            color: #6a0dad;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input, .form-group textarea {
            padding: 10px;
            border: 1px solid #d3c0e5;
            border-radius: 5px;
            font-size: 14px;
            background-color: #f9f5fc;
        }

        .form-group textarea {
            resize: none;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #6a0dad;
            color: #ffffff;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #5a0ca3;
        }

        .info {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }

        .info div {
            text-align: center;
            background-color: #f9f5fc;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #d3c0e5;
            color: #6a0dad;
            font-size: 14px;
        }

        footer {
            width: 100%;
            background-color: #333;
            color: white;
            padding: 20px 0;
            font-family: Arial, sans-serif;
            
        }

   
        .footer-container {
    display: flex;
    justify-content: space-between;
    padding: 0 50px;
}

.footer-section {
    width: 30%;
}

.footer-section h4 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #9b7dd3; 
}

.footer-section p {
    font-size: 14px;
    line-height: 1.6;
    color: #ddd;
}

.social-media-icons {
    margin-top: 10px;
}

.social-icon {
    text-decoration: none;
    font-size: 20px;
    color: white;
    margin-right: 10px;
    transition: color 0.3s;
}

.social-icon:hover {
    color: #8A2BE2;
}

.footer-bottom {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
    color: #ddd;
}

.footer-bottom p {
    margin: 0;
}

    </style>
</head>
<body>
    <nav>
        <div class="logo">
            Doğal <span>Taşlar</span>
        </div>
        <ul>
            <li><a href="anasayfa.php">Anasayfa</a></li>
            <li><a href="urunler.php">Ürünler</a></li>
            <li><a href="dogal-tas-ozellikleri.php">Doğal Taş Özellikleri</a></li>
            <li><a href="contact.php">İletişim</a></li>
        </ul>
        <div class="navbar">
            <a href="giris.php" class="login-btn">
                <i class="fas fa-sign-in-alt"></i> Giriş
            </a>
        </div>
        <div class="cart">
            <a href="cart.php">
                <i class="fas fa-shopping-cart"></i> Sepetim
            </a>
        </div>
    </nav>
    <div class="contact-container">
        <h1>Bize Ulaşın</h1>
        <div class="info">
            <div>
                <p>📍 Mareşal Fevzi Mahallesi 2.Murat Caddesi No:25 </p>
                <p>Odunpazarı/Eskişehir</p>
            </div>
            <div>
                <p>📧 tasritmi@gmail.com</p>
            </div>
            <div>
                <p>📞 +90 222 456 789</p>
            </div>
        </div>
        <form>
            <div class="form-group">
                <label for="name">Adınız</label>
                <input type="text" id="name" name="name" placeholder="Adınızı giriniz" required>
            </div>
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" placeholder="E-posta adresinizi giriniz" required>
            </div>
            <div class="form-group">
                <label for="subject">Konu</label>
                <input type="text" id="subject" name="subject" placeholder="Konu başlığı" required>
            </div>
            <div class="form-group">
                <label for="message">Mesaj</label>
                <textarea id="message" name="message" rows="5" placeholder="Mesajınızı buraya yazınız" required></textarea>
            </div>
            <button type="submit">Mesaj Gönder</button>
        </form>
    </div>
    <footer>
    <div class="footer-container">
        <div class="footer-section">
            <h4>Hakkımızda</h4>
            <p>"Doğanın enerjisini evinize taşıyoruz!" Şifa Taşları olarak, doğal taşların iyileştirici gücüne inanıyor ve bu eşsiz enerjiyi sizlerle buluşturuyoruz. Kaliteli ve özenle seçilmiş taşlarımızla, ruhunuzu ve yaşam alanlarınızı dengelemenize yardımcı oluyoruz.</p>
        </div>
        <div class="footer-section">
            <h4>İletişim</h4>
            <p>Telefon: +90 222 456 789</p>
            <p>Email: tasritmi@gmail.com</p>
            <p>Adres: Mareşal Fevzi Mahallesi 2.Murat Caddesi No:25 Odunpazarı/Eskişehir </p>
        </div>
        <div class="footer-section">
            <h4>Sosyal Medya</h4>
            <div class="social-media-icons">
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-twitter"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-instagram"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2025 Taş Ritmi. Tüm Hakları Saklıdır.</p>
    </div>
</footer>

</body>
</html>
