<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Ayarlar</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}
.navbar {
            background-color: rgb(36, 64, 99);
            color: white;
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .navbar-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 40px;
        }

        .navbar-header img {
            width: 80px;
            height: auto;
            margin-bottom: 15px;
            border-radius: 50%;
        }

        .navbar-header h1 {
            font-size: 20px;
            margin: 0;
            font-weight: bold;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 12px 15px;
            font-weight: 500;
            margin: 5px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            display: flex;
            align-items: center;
        }

        .navbar a:hover {
            background-color:rgb(36, 64, 99);
            transform: translateX(5px);
        }

        .navbar a i {
            margin-right: 10px;
        }
        h1 {
    text-align: center;
    color: #f4f4f4;
}


.settings-container {
    max-width: 600px;
    margin: 50px auto;
    padding: 70px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color:rgb(0, 0, 0);
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

input, textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

textarea {
    height: 100px;
    resize: none;
}

button.btn {
    display: block;
    width: 100%;
    padding: 10px;
    background-color:rgb(36, 64, 99);
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

button.btn:hover {
    background-color: #5d2e70;
}

    </style>
</head>
<body>
<div class="navbar">
        <div class="navbar-header">
            <img src="https://cdn.tassandigi.com/2024/04/renk-degistiren-dogal-taslar.jpeg" alt="">
            <h1>Doğal Taş</h1>
        </div>
        <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
        <a href="setting.php"><i>⚙️</i> Ayarlar</a>
        <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
        <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
    </div>
    <div class="settings-container">
        <h2>Site Ayarları</h2>
        <form action="ayarlar.php" method="POST">
            <div class="form-group">
                <label for="site_title">Site Başlığı:</label>
                <input type="text" id="site_title" name="site_title" placeholder="Site başlığını girin" required>
            </div>
            <div class="form-group">
                <label for="site_description">Site Açıklaması:</label>
                <textarea id="site_description" name="site_description" placeholder="Site açıklamasını girin" required></textarea>
            </div>
            <div class="form-group">
                <label for="email">E-posta:</label>
                <input type="email" id="email" name="email" placeholder="E-posta adresini girin" required>
            </div>
            <div class="form-group">
                <label for="phone">Telefon:</label>
                <input type="text" id="phone" name="phone" placeholder="Telefon numarasını girin" required>
            </div>
            <button type="submit" class="btn">Kaydet</button>
        </form>
    </div>
</body>
</html>
