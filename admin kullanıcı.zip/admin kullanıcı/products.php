
<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürünler Yönetimi</title>
    <style>
        body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f7f7f7;
    color: #333;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

        .navbar {
            background-color: rgb(36, 64, 99);
            color: white;
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .navbar-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 40px;
        }

        .navbar-header img {
            width: 80px;
            height: auto;
            margin-bottom: 15px;
            border-radius: 50%;
        }

        .navbar-header h1 {
            font-size: 20px;
            margin: 0;
            font-weight: bold;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 12px 15px;
            font-weight: 500;
            margin: 5px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            display: flex;
            align-items: center;
        }

        .navbar a:hover {
            background-color:rgb(36, 64, 99);
            transform: translateX(5px);
        }

        .navbar a i {
            margin-right: 10px;
        }

        .content {
            margin-left: 270px;
            padding: 40px;
            flex: 1;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
       
       

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            color:rgb(233, 226, 226);
            margin-bottom: 40px;
        }
        h2 {
            text-align: center;
            font-size: 32px;
            color:rgb(0, 0, 0);
            margin-bottom: 40px;
        }

        .product-form {
            background: #fff;
            padding: 60px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
        }

        .product-form label {
            display: block;
            margin: 10px 0 5px;
            font-size: 16px;
        }

        .product-form input, .product-form select, .product-form textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            color: #333;
        }

        .product-form button {
            background: rgb(36, 64, 99);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .product-form button:hover {
            background: rgb(36, 64, 99);
        }

        .product-list {
            margin-top: 40px;
        }

        .product-list table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .product-list th, .product-list td {
            padding: 18px 20px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .product-list th {
            background: rgb(36, 64, 99);
            color: white;
        }

        .product-list td {
            background: #f9f9f9;
        }

        .product-list td .action-btn {
            background: rgb(36, 64, 99);
            color: white;
            padding: 5px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            margin-right: 10px;
            margin-top:10px;
            transition: background 0.3s ease, transform 0.1s ease;
        }

        .product-list td .action-btn:hover {
            background: rgb(36, 64, 99);
            transform: scale(1.05);
        }

        .product-list td .action-btn:active {
            background: rgb(36, 64, 99);
            transform: scale(0.98);
        }

        .product-list td .action-btn:last-child {
            margin-right: 0;
        }

       
        @media (max-width: 768px) {
            .product-form input, .product-form select, .product-form textarea, .product-form button {
                padding: 10px;
            }

            .product-list th, .product-list td {
                padding: 12px;
            }
        }

    </style>
</head>
<body>
<div class="navbar">
        <div class="navbar-header">
            <img src="https://cdn.tassandigi.com/2024/04/renk-degistiren-dogal-taslar.jpeg" alt="">
            <h1>Doğal Taş</h1>
        </div>
        <a href="panel.php"><i>🏠</i> Ana Sayfa</a>
        <a href="setting.php"><i>⚙️</i> Ayarlar</a>
        <a href="products.php"><i>🛒</i> Ürün Yönetimi</a>
        <a href="logout.php"><i>🚪</i> Çıkış Yap</a>
    </div>
    <div class="container">
        <h2>Ürünler Yönetimi</h2>

     
        <div class="product-form">
    <h3>Yeni Ürün Ekle</h3>
    <form method="POST" action="add_product.php" enctype="multipart/form-data">
        <label for="product-name">Ürün Adı:</label>
        <input type="text" id="product-name" name="product_name" required>

        <label for="product-price">Fiyat:</label>
        <input type="number" id="product-price" name="product_price" step="0.01" required>

        <label for="product-stock">Stok Adedi:</label>
        <input type="number" id="product-stock" name="product_stock" required>

        <label for="product-category">Kategori:</label>
        <select id="product-category" name="product_category">
            <option value="Ana Sayfa">Ana Sayfa</option>
            <option value="Ürünler">Ürünler</option>
        </select>

        <label for="product-description">Açıklama:</label>
        <textarea id="product-description" name="product_description" rows="4"></textarea>


        <label for="product-image">Ürün Fotoğrafı:</label>
        <input type="file" id="product-image" name="product_image" accept="image/*">

        <button type="submit">Ekle</button>
    </form>
</div>



        <div class="product-list">
            <h2>Mevcut Ürünler</h2>
            <table>
                <thead>
                    <tr>
                        <th>Ürün Adı</th>
                        <th>Fiyat</th>
                        <th>Stok</th>
                        <th>Kategori</th>
                        <th>Açıklama</th>
                        <th>Fotoğraf</th> 
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
    
                    <?php
          
            $conn = new mysqli('localhost', 'root', '', 'natural_stones');
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }
            $result = $conn->query("SELECT * FROM products");

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            
                    $image_path = 'uploads/' . $row['image'];
                    echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['price']}</td>
                        <td>{$row['stock']}</td>
                        <td>{$row['category']}</td>
                        <td>{$row['description']}</td>
                        <td>";
             
                        if (!empty($row['image']) && file_exists($image_path)) {
                            echo "<img src='{$image_path}' alt='Ürün Fotoğrafı' style='width: 100px; height: 100px; object-fit: cover;'>";
                        } else {
                            echo "Fotoğraf yok";
                        }
                    echo "</td>
                        <td>
                            <button class='action-btn'>Düzenle</button>
                            <button class='action-btn'>Güncelle</button>
                            <form method='POST' action=''>
                                        <input type='hidden' name='product_id' value='{$row['id']}'>
                                        <button type='submit' name='delete' class='action-btn'>Sil</button>
                                    </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align: center;'>Henüz ürün eklenmedi.</td></tr>";
            }

            $conn->close();
            ?>
                </tbody>
            </table>
        </div>

      
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
            $product_id = $_POST['product_id'];

        
            $conn = new mysqli('localhost', 'root', '', 'natural_stones');
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }

     
            $delete_query = "DELETE FROM products WHERE id = ?";
            $stmt = $conn->prepare($delete_query);
            $stmt->bind_param('i', $product_id);
            $stmt->execute();

       
            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Ürün başarıyla silindi.'); window.location.href = window.location.href;</script>";
            } else {
                echo "<script>alert('Bir hata oluştu. Ürün silinemedi.');</script>";
            }

            $stmt->close();
            $conn->close();
        }
?>

    </div>
    </div>
</body>
</html>