-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 10 Oca 2025, 15:22:24
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `natural_stones`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `stock`, `category`, `description`, `image`) VALUES
(22, 'Firuze Taşı', 58.00, 5, 'Ürünler', 'Firuze taşı, dikkat çekici mavi ve yeşil tonlarıyla bilinen, değerli ve antik dönemlerden beri takı ve süs eşyalarında kullanılan bir taş olarak kabul edilmektedir. Firuze taşının, özellikle korunma ve şifa taşı olduğuna inanılmaktadır. Bu taşın, negatif enerjileri uzaklaştırdığı ve kişiyi kötü enerjilere karşı koruduğu düşünülmektedir. Aynı zamanda, duygusal dengeyi sağladığı ve zihinsel huzuru artırdığı kabul edilen bir taştır.', 'Turkuaz Tasi.webp'),
(23, 'Amazonit Taşı', 70.00, 10, 'Ana Sayfa', '“Umut” taşı olarak bilinmektedir. Yüksek enerjiye sahip olan Amazonit taşı, kullanıcıların hayatında çıkan aksiliklerin, engellerin ve zorlukların üstesinden gelmeleri için rehberlik etmektedir. Korkuları, şüpheleri ve endişeleri ortadan kaldırdığına inanılmaktadır. Düşük enerjiyi, pozitif bir enerjiye çevirir.', 'Amazonit Tasi.webp'),
(24, 'Kaplan Gözü Taşı', 60.00, 10, 'Ana Sayfa', 'Kaplan Gözü taşı, altın sarısı ve kahverengi tonlarıyla dikkat çeken, ışığın yansımasıyla göz alıcı bir parlaklık sergileyen bir kuvars çeşidi olarak bilinir. Bu taşın cesaret, güç ve odaklanma enerjisini teşvik ettiğine inanılır. Kaplan Gözü’nün, kişisel güveni arttırarak kişinin hayatta karşılaştığı zorluklarla başa çıkma yeteneğini güçlendirdiği düşünülmektedir. Ayrıca, taşıyan kişinin negatif enerjilerden korunmasına ve zihinsel netlik kazanmasına yardımcı olduğu kabul edilir. Özellikle karar verme süreçlerinde Kaplan Gözü taşının, kararlılık ve irade gücünü desteklediği bilinmektedir.', 'Kaplan Gozu Tasi.webp'),
(25, 'Güneş Taşı', 55.00, 6, 'Ana Sayfa', 'Güneş taşı, İngilizcede ‘Sunstone’ olarak bilinir. Kuvars grubunda yer alan Güneş taşının tarihi yüzyıllar öncesine dayanır. Viking dönemi antik kalıntılarında Güneş taşları bulunmuştur. Kahverengi-turuncu ateş gibi bir görünüme sahip Güneş taşı genelde opak formuyla karşımıza çıkar. Yaşama sevincini temsil ettiğine inanılan bu taşın, kullanan kişiyi özgüvenli, azimli ve enerjik hâle getirdiği söylenir.', 'Gunes Tasi.webp'),
(26, 'Jasper Taşı', 65.00, 5, 'Ana Sayfa', 'Jasper taşı faydaları nelerdir? Jasper taşı, birçok kişi tarafından güçlü bir koruyucu ve dengeleyici özelliklere sahip olduğu kabul edilen bir taş olarak bilinmektedir. Jasper taşı faydaları arasında, özellikle stresli ve zorlayıcı durumlarda zihinsel sakinlik sağlaması ve duygusal dengeyi desteklemesi yer almaktadır. Bu taşın, topraklama enerjisi ile kişinin fiziksel dünyayla daha sağlam bir bağ kurmasına yardımcı olduğu düşünülmektedir.', 'Jasper Tasi.webp'),
(27, 'Ametist Taşı', 69.00, 10, 'Ana Sayfa', 'Ametist, sakinleştirici ve dengeleyici etkileriyle bilinir. Stresi hafifletici, meditasyon sırasında zihni açıcı bir taş olarak kullanılır ve iletişim becerilerini geliştirdiği, özgüveni artırdığı düşünülür. Tarih boyunca Antik Mısır\'dan Yunan ve Roma\'ya kadar pek çok medeniyetin süs eşyası ve tılsım olarak kullandığı bu taş, günümüzde de takılarda, dekoratif objelerde ve enerji terapilerinde önemli bir yere sahiptir.', 'Ametist Tasi.webp'),
(28, 'Aventurin Taşı', 75.00, 5, 'Ana Sayfa', 'Aventurin taşı, genellikle yeşil rengiyle bilinen ve birçok kişi tarafından şans ve bolluk taşı olarak kabul edilen bir doğal taştır. Aventurin taşı, içindeki ince mika parçacıkları sayesinde hafif ışıltılı bir görünüme sahip olup, bu taşın enerjisinin kişinin yaşamında pozitif değişiklikler getirdiği düşünülmektedir. Bu taşın, özellikle cesaret ve kararlılığı artırarak yeni fırsatları çekmeye yardımcı olduğu kabul edilmektedir. Aynı zamanda, aventurin taşının stres ve kaygıyı hafifletmeye katkıda bulunduğu, kişinin duygusal dengeyi bulmasına yardımcı olduğu düşünülmektedir.', 'Aventurin Tasi.webp'),
(29, 'Kalsit Taşı', 56.00, 8, 'Ana Sayfa', '\r\nAkıl ve duygular arasında bağlantı kurmayı sağlar. Bu sayede duygusal zekayı geliştirerek her duyguyu dengede yaşamaya yardım eder.Tembellikle savaşarak fiziksel ve zihinsel enerjiyi yükselten taş, onu üzerinde taşıyan kişiye motivasyon ve umut verir.Arındırıcı ve yenileyici özelliği sayesinde kişiye yeni bir bakış açısı kazandırır. Duygusal blokajları kaldırarak hayattan keyif almayı sağlar.Hafızayı güçlendirir ve analiz yeteneğini arttırır. Çalışmaya teşvik eden taş, bu özelliği ile öğrenciler için faydalıdır.Spiritüel gelişimi destekleyen kalsit taşı, psişik yetenekleri arttırmak için kullanılabilir.\r\n\r\n', 'Kalsit Tasi.webp'),
(31, 'Karnelyan Taşı', 50.00, 15, 'Ana Sayfa', 'Doğal taşlar arasında Karneol akik taşı, isminden de anlaşılacağı üzere akik taşının ateş kırmızısı rengindeki versiyonudur. Bu taş, kalsedeon kuvarsının bir türü olup, yarı saydam özellikte bir mineraldir. Genellikle kırmızının farklı tonlarında bulunmakla beraber, ateş kırmızısı renginde olanı daha yaygındır.\r\nBant sistemi ya çok hafif, ya da hiç yoktur. Yaşama sevincini temsil ettiğine inanılan Karnelyan, sadakat ve yenilik taşı olarak görülür.', 'Karnelyan Tasi.jpg'),
(32, 'Amazonit Taşı', 65.00, 10, 'Ürünler', '“Umut” taşı olarak bilinmektedir. Yüksek enerjiye sahip olan Amazonit taşı, kullanıcıların hayatında çıkan aksiliklerin, engellerin ve zorlukların üstesinden gelmeleri için rehberlik etmektedir. Korkuları, şüpheleri ve endişeleri ortadan kaldırdığına inanılmaktadır. Düşük enerjiyi, pozitif bir enerjiye çevirir.', 'Amazonit1 Tasi.webp'),
(33, 'Ay Taşı', 68.00, 8, 'Ürünler', '“Umut” taşı olarak bilinmektedir. Yüksek enerjiye sahip olan Amazonit taşı, kullanıcıların hayatında çıkan aksiliklerin, engellerin ve zorlukların üstesinden gelmeleri için rehberlik etmektedir. Korkuları, şüpheleri ve endişeleri ortadan kaldırdığına inanılmaktadır. Düşük enerjiyi, pozitif bir enerjiye çevirir.', 'Ay Tasi.webp'),
(34, 'Çilek Kuvars Taşı', 75.00, 5, 'Ürünler', 'Çilek Kuvars taşı, yabancı dilde \'Strawberry quartz\' olarak bilinir. ‘İç Sevgi Taşı’ diye de isimlendirilmiştir. Kuvars grubuna mensup olan pembe renkli bir taştır. Fakat ‘Pembe Kuvars’ ile Çilek Kuvars birbirine karıştırılmamalıdır. Pembe Kuvars’ın rengi daha açıktır, Çilek Kuvars taşının pembe tonu ise daha farklıdır. Çok güçlü bir kristal olan Çilek Kuvars, buna rağmen oldukça nazik, sevgi dolu, destekleyici, yumuşak ve kucaklayıcı bir enerjiye sahiptir.', 'Cilek Kuvars Tasi.webp'),
(35, 'Labradorit Taşı', 69.00, 4, 'Ürünler', 'Labradorit taşı, kendine has kahverengi, yeşil ve mavi renk geçişleriyle tanınan bir doğal taştır. Bu taşın en belirgin özelliği, farklı açılardan bakıldığında ışığa göre renk değiştirmesidir; bilimsel olarak bu etkiye \"labradoresans\" denir. Labradorit, bu muhteşem ışık ve renk oyunları sayesinde takı yapımında ve dekorasyon alanında sıkça tercih edilir.', 'Labradorit Tasi.webp'),
(36, 'Lapis Lazuli Taşı', 80.00, 20, 'Ürünler', 'Lapis Lazuli, birçok kültürde derin anlamlar taşıdığına inanılan ve zengin mavi rengiyle dikkat çeken bir taş olarak kabul edilmektedir. Eski Mısır\'dan Mezopotamya\'ya kadar birçok medeniyetin bu taşı, ruhsal koruma ve bilgelik kaynağı olarak gördüğü bilinmektedir. Lapis Lazuli\'nin zihinsel netliği artırdığı ve içsel bilgelik ile bağlantı kurmaya yardımcı olduğu düşünülmektedir. Ayrıca, bu taşın etkili iletişimi desteklediği ve kişinin kendini daha net ifade etmesine katkı sağladığı kabul edilir.', 'Lapis Lazuli Tasi.webp'),
(37, 'Malahit Taşı', 55.00, 15, 'Ürünler', 'Malakit,  parlak yeşil renkli bir mineraldir ve bakır karbonattan meydana gelir. Doğada yaygın bulunan Malahit’in esasen bir bakır cevheri olduğu söylenebilir. Onun için, ‘Bakır Taşı’ diye de isimlendirilmiştir. Oksitlenme sonucunda oluşur. Malakit, oksitlenme neticesinde meydana gelmiş bir taştır. Derin ve koyu bir yeşil rengi vardır. Bir söylentiye göre ismi, Yunancadaki \'makalos\' (yumuşak) kelimesinden gelir.‘Dönüşüm Taşı’ olarak kabul edilen bu taş, eski çağlarda saray süslemeleri ve kral taçları için kullanılmıştır.Mısırlılar tarafından M.Ö 400 yılında Süveyş madeninden çıkarılmıştır. Kraliçe Kleopatra\'nın da sıkça kullandığı söylenen Malakit, aksesuarların yapımında ve göz farları için pigment üretiminde tercih edilmiştir.', 'Malahit Tasi.webp'),
(38, 'Obsidyen Taşı', 66.00, 18, 'Ana Sayfa', 'Obsidyen taşı, volkanik cam olarak da bilinen, siyah ve koyu renk tonlarıyla dikkat çeken güçlü bir doğal taş olarak kabul edilmektedir. Bu taşın, yoğun enerjisi nedeniyle koruyucu özelliklere sahip olduğuna inanılır ve negatif enerjiyi absorbe ederek kişiyi zararlı etkilerden koruduğu düşünülmektedir. Obsidyenin, özellikle aurayı temizlediği, enerji blokajlarını giderdiği ve ruhsal dengeyi sağladığı kabul edilmektedir. Zihinsel berraklık ve gerçekleri olduğu gibi görme yeteneğini artırdığına inanılan obsidyen, aynı zamanda kişinin içsel dünyasında derinlemesine bir yolculuğa çıkmasına yardımcı olduğu düşünülmektedir. ', 'Obsidyen Tasi.webp'),
(39, 'Opalit Taşı', 50.00, 5, 'Ana Sayfa', 'Opalit insan üretimi olan sentetik bir camdır.Işığı ve yansımaları ile kendine hayran bırakan bu taş genelde dekoratif amaçlarla kullanılıyor.Çoğu zaman opalit taşı bazı satıcılar tarafından ay taşı olarak satılabiliyor.Opalit, hayal gücünün neler yapabileceğine dair çok güzel bir örnektir.Bu sebeple gençlik, heyecan ve mucizeler ile ilişkilendirilir.Hayata iyimserlik ve merakla bakmaya destek olur.Pozitif ve sıcak enerjisiyle olumsuzlukları dışarı atar.', 'Opalit Tasi.webp'),
(40, 'Peridot Taşı', 56.00, 9, 'Ana Sayfa', 'Doğal taşlar arasında Peridot taşı (Zebercet ), ‘Olivin’ ailesine mensup bir mineraldir.Çoğunlukla Zümrüt taşına benzetilir. Canlı bir parlaklığa sahiptir ve efervesan yeşil tonları ile çarpıcı bir görünüm uyandırır. Birçok allokromatik kıymetli taşın aksine, kendine has bir güzelliği vardır. Bunu, yapısındaki özel kimyasal bileşime borçludur.Koyu yeşil, şişe yeşili, soluk yeşil gibi farklı tonlarda değişen renk yelpazesinde karşımıza çıkar. Ağustos\'ta dünyaya gelenlerin doğum taşı olup, evliliğin 16. Yıldönümünde hediye verilmesinin uğur getireceğine inanılır.\r\n\r\n', 'Peridot Tasi.webp'),
(41, 'Serpantin Taşı', 64.00, 10, 'Ana Sayfa', 'Serpantin taşı, serpantin familyasına ait bir grup minerali içerir ve bu özelliği ile benzersiz bir görünüme sahiptir. Serpantin taşı, hem görünüm hem de enerji açısından oldukça zengindir. Kullanıcılarına sakinlik ve huzur getirir, stres ve negatif enerjiyi uzaklaştırır.', 'Serpantin Tasi.webp'),
(42, 'Sitrin Taşı', 74.00, 8, 'Ürünler', 'Sitrin taşı, enerjisi ve parlaklığı ile dikkat çeken, altın sarısı rengi ile tanınan popüler doğal taşlardan biridir. Doğal taşlar arasında \"bolluk ve bereket taşı\" olarak bilinen sitrin, aynı zamanda pozitif enerjiyi çektiği ve ruhsal denge sağladığı düşünülmektedir. Sitrin taşının, özellikle zihinsel berraklık, enerji artışı ve motivasyon sağladığı kabul edilir. Sitrin taşı, parlak sarı rengiyle tanınan ve özellikle pozitif enerji taşıdığına inanılan bir doğal taş olarak kabul edilmektedir. Sitrin taşı, adını limon sarısı renginden alır ve bu rengin, güneş ışığını ve yaşam enerjisini temsil ettiği düşünülmektedir. Bu taşın, zihinsel netlik sağladığı ve kişinin kendine güvenini artırdığı kabul edilmektedir. Ayrıca, sitrin taşının bolluk ve bereket çektiği, finansal başarıya katkı sağladığı düşünülmektedir.', 'Sitrin Tasi.webp'),
(43, 'Siyah Oniks Taşı', 65.00, 13, 'Ürünler', 'Onix taşı, doğal bir mineral olup genellikle siyah renkte olmasının yanı sıra bazen mavi, yeşil, kahverengi ve gri tonlarında da bulunabilir. Genellikle dekoratif amaçlarla kullanılan oniks taşı, aynı zamanda takı ve süs eşyalarında da sıkça tercih edilmektedir. Oniks taşı, tarih boyunca farklı kültürlerde farklı anlamlara gelmiştir. Antik Roma ve Yunan mitolojilerinde oniks taşı, cesaret ve kararlılık sembolü olarak kabul edilmiştir. Ayrıca, oniks taşının zihinsel ve duygusal dengeyi sağladığına inanılmaktadır.', 'Siyah Oniks.webp'),
(44, 'Siyah Turmalin Taşı', 54.00, 6, 'Ürünler', 'Turmalin taşı, enerji dengeleme ve koruma özellikleriyle bilinen bir kristaldir. Bu taşın, negatif enerjileri uzaklaştırdığına ve bireyi olumsuz etkilerden koruduğuna inanılmaktadır. Farklı renklerde bulunan turmalinin, her bir renginin farklı enerji merkezleriyle etkileşime geçtiği kabul edilir; örneğin, siyah turmalinin kök çakrayı dengelediği ve topraklanma sağladığı düşünülürken, pembe turmalinin kalp çakrasını açtığı ve sevgi enerjisini artırdığı bilinmektedir. Aynı zamanda, turmalinin ruhsal farkındalığı artırdığı ve zihinsel berraklık sağladığı kabul edilmektedir. Stresten arınma ve iç huzur sağlama konusunda yardımcı olabileceğine inanılan turmalin, meditasyon pratiğinde de sıkça kullanılan bir taştır. Doğal yapısı gereği, bulunduğu ortama pozitif enerji yaydığı ve kişisel enerji alanını güçlendirdiği düşünülmektedir. Turmalin taşı, spiritüel ve duygusal dengeyi destekleyen güçlü bir taş olarak kabul edilmektedir.', 'Siyah Turmalin Tasi.webp'),
(45, 'Sodalit Taşı', 45.00, 15, 'Ürünler', 'Sodalit; nirvana, mantık ve akıl taşı olarak bilinir. Duyguların paylaşımında büyük rol üstlendiği söylenen bu taşın, beyin gücünü artırdığına da inanılmaktadır.Kaya görünümlü bu mineral, mor ve mavi renkleriyle karşımıza çıkar. Tesbih, küpe, kolye ve bileklik gibi ürünlerin yapımında yaygın olarak kullanılabilir. Kütle veya pandül gibi obje şeklinde de tercih edilmesi mümkündür.', 'Sodalit Tasi.webp'),
(46, 'Unakit Taşı', 59.00, 20, 'Ürünler', 'Unakit taşı, kırmızı ortoklaz (pembe Feldspar), Kuvars ve Yeşil Epidotin bir kombinasyonudur. Granite benzeyen bir yapısı vardır.\r\n‘Titreşim taşı’ diye bilinen ve psişik görüşü açtığı söylenen bu taşın, Üçüncü Göz Çakrası ile etkileşime girdiği belirtilir. Hayattan istediklerimizi elde etmemize yardımcı olduğu kabul edilen Unakit taşının, daha iyi uyumayı da kolaylaştırdığına inanılır.', 'Unakit Tasi.webp');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Tablo için indeksler `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
